Projeto: site-amparo
Conteúdo: Projeto React (Create React App style) com TailwindCSS já configurado.
Como usar:
1) Instale dependências:
   npm install
2) Rode o site:
   npm start
Observações:
- Tailwind está configurado (tailwind.config.cjs, postcss.config.cjs). Se já tiver create-react-app com Vite ou outro, adapte conforme necessário.
- O formulário é client-side apenas. Substitua handleSubmit em src/App.jsx por integração com seu backend ou serviço de email.
