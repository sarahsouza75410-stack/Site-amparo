import React, { useState } from "react";

// Amparo Sênior Core — One Page React Component
// - TailwindCSS classes assumed (see README for setup)
// - Logo image is used from /src/assets/logo.png

import LogoImg from "./assets/logo.png";

export default function App() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50 text-slate-800 antialiased font-sans">
      {/* NAV */}
      <header className="fixed inset-x-0 top-0 bg-white/90 backdrop-blur-sm border-b border-slate-100 z-40">
        <div className="max-w-6xl mx-auto px-6 py-3 flex items-center justify-between">
          <a href="#hero" className="flex items-center gap-3">
            <img src={LogoImg} alt="Amparo Sênior Core" className="w-12 h-12 object-contain"/>
            <div>
              <div className="text-lg font-semibold">Amparo <span className="text-teal-600">Sênior</span> Core</div>
              <div className="text-xs text-slate-500 -mt-1">Cuidado especializado para sua família</div>
            </div>
          </a>

          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#sobre" className="hover:text-teal-600">Sobre</a>
            <a href="#servicos" className="hover:text-teal-600">Serviços</a>
            <a href="#depoimentos" className="hover:text-teal-600">Depoimentos</a>
            <a href="#contato" className="hover:text-teal-600">Contato</a>
            <a href="#contato" className="bg-teal-600 text-white px-4 py-2 rounded-md shadow hover:opacity-95">Solicitar Cuidado</a>
          </nav>

          <div className="md:hidden">
            <button onClick={() => setMobileOpen(!mobileOpen)} aria-label="menu" className="p-2">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M4 7h16M4 12h16M4 17h16" stroke="#0B3D91" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
            </button>
          </div>
        </div>

        {mobileOpen && (
          <div className="md:hidden border-t border-slate-100 bg-white">
            <div className="px-6 py-4 flex flex-col gap-3">
              <a href="#sobre" onClick={() => setMobileOpen(false)} className="py-2">Sobre</a>
              <a href="#servicos" onClick={() => setMobileOpen(false)} className="py-2">Serviços</a>
              <a href="#depoimentos" onClick={() => setMobileOpen(false)} className="py-2">Depoimentos</a>
              <a href="#contato" onClick={() => setMobileOpen(false)} className="py-2">Contato</a>
            </div>
          </div>
        )}
      </header>

      <main className="pt-20">
        {/* HERO */}
        <section id="hero" className="max-w-6xl mx-auto px-6 py-16 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <h1 className="text-4xl md:text-5xl font-extrabold leading-tight text-slate-900">Cuidado especializado e humano para quem você ama</h1>
            <p className="mt-6 text-lg text-slate-600">Na <strong>Amparo Sênior Core</strong> oferecemos atendimento domiciliar e acompanhamento profissional com foco em segurança, conforto e bem-estar. Nossos cuidadores são selecionados, treinados e acompanhados por equipes de enfermagem.</p>

            <div className="mt-8 flex gap-4">
              <a href="#contato" className="inline-flex items-center px-5 py-3 bg-teal-600 text-white rounded-md shadow">Solicitar orçamento</a>
              <a href="#servicos" className="inline-flex items-center px-5 py-3 border border-slate-200 rounded-md">Ver serviços</a>
            </div>

            <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-4">
              <Stat label="Atendimentos" value="+1.200" />
              <Stat label="Cuidadores" value="+85" />
              <Stat label="Avaliação" value="4.8/5" />
              <Stat label="Área" value="Grande cidade" />
            </div>
          </div>

          <div>
            <div className="w-full bg-white border border-slate-100 rounded-2xl shadow p-6">
              <h3 className="text-lg font-semibold">Solicitar contato</h3>
              <p className="text-sm text-slate-500 mt-1">Preencha os dados e nossa equipe retornará em até 24h úteis.</p>

              <ContactForm />
            </div>

            <div className="mt-6 text-xs text-slate-500">Atendimento: Seg — Sex, 8h — 18h • Emergência 24h (sob solicitação)</div>
          </div>
        </section>

        {/* SOBRE */}
        <section id="sobre" className="max-w-6xl mx-auto px-6 py-16">
          <div className="grid md:grid-cols-2 gap-10 items-center">
            <div>
              <h2 className="text-3xl font-bold">Quem somos</h2>
              <p className="mt-4 text-slate-600">A <strong>Amparo Sênior Core</strong> nasceu para oferecer uma alternativa segura e confiável para famílias que buscam cuidadores qualificados. Unimos tecnologia, protocolos de atendimento e acompanhamento humano para garantir tranquilidade aos clientes.</p>

              <ul className="mt-6 space-y-3">
                <li className="flex items-start gap-3">
                  <div className="mt-1 w-8 h-8 flex items-center justify-center rounded-full bg-blue-50 text-blue-600">✓</div>
                  <div>
                    <div className="font-semibold">Seleção e treinamento rigorosos</div>
                    <div className="text-sm text-slate-500">Todos os cuidadores passam por checagem de antecedentes e formação técnica.</div>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="mt-1 w-8 h-8 flex items-center justify-center rounded-full bg-blue-50 text-blue-600">✓</div>
                  <div>
                    <div className="font-semibold">Acompanhamento de enfermagem</div>
                    <div className="text-sm text-slate-500">Planos com supervisão periódica por profissionais de saúde.</div>
                  </div>
                </li>
              </ul>
            </div>

            <div>
              <div className="bg-white rounded-2xl shadow p-6 border border-slate-100">
                <h3 className="font-semibold">Missão</h3>
                <p className="text-sm text-slate-600 mt-2">Prover cuidados humanizados que promovam qualidade de vida, autonomia e segurança aos idosos e tranquilidade às famílias.</p>

                <h3 className="font-semibold mt-4">Visão</h3>
                <p className="text-sm text-slate-600 mt-2">Ser referência regional em cuidado domiciliar e acompanhamento sênior até 2028.</p>

                <h3 className="font-semibold mt-4">Valores</h3>
                <ul className="text-sm text-slate-600 mt-2 space-y-1">
                  <li>Empatia • Confidencialidade • Profissionalismo • Excelência</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* SERVIÇOS */}
        <section id="servicos" className="bg-white border-t border-slate-100">
          <div className="max-w-6xl mx-auto px-6 py-16">
            <h2 className="text-3xl font-bold">Nossos serviços</h2>
            <p className="mt-2 text-slate-600">Soluções personalizadas para as necessidades de cada família.</p>

            <div className="mt-8 grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <ServiceCard title="Cuidado domiciliar" desc="Assistência nas atividades diárias (higiene, alimentação, administração de medicamentos e companhia)." />
              <ServiceCard title="Acompanhamento hospitalar" desc="Profissionais que acompanham internamento e procedimentos, garantindo continuidade do cuidado." />
              <ServiceCard title="Enfermagem especializada" desc="Enfermeiros para cuidados técnicos: curativos, administração de medicamentos complexos e monitoramento." />
              <ServiceCard title="Apoio emocional e recreativo" desc="Atividades de estimulação cognitiva, socialização e suporte emocional para bem-estar." />
            </div>
          </div>
        </section>

        {/* DEPOIMENTOS */}
        <section id="depoimentos" className="max-w-6xl mx-auto px-6 py-16">
          <h2 className="text-3xl font-bold">Depoimentos</h2>
          <p className="text-slate-600 mt-2">O que as famílias falam sobre nosso trabalho</p>

          <div className="mt-8 grid md:grid-cols-3 gap-6">
            <Testimonial name="Mariana R." text={`A Amparo trouxe segurança para nossa família. O cuidador é carinhoso e muito profissional.`} />
            <Testimonial name="Roberto S." text={`Atendimento rápido e sensível. Recomendo para quem busca confiança.`} />
            <Testimonial name="Lúcia M." text={`O acompanhamento fez diferença no bem-estar do meu pai — muito grata à equipe.`} />
          </div>
        </section>

        {/* CONTATO */}
        <section id="contato" className="bg-white border-t border-slate-100">
          <div className="max-w-6xl mx-auto px-6 py-16 grid md:grid-cols-2 gap-8 items-start">
            <div>
              <h2 className="text-3xl font-bold">Fale conosco</h2>
              <p className="mt-2 text-slate-600">Solicite um orçamento ou tire dúvidas. Nossa equipe terá prazer em ajudar.</p>

              <div className="mt-6 space-y-3 text-sm text-slate-600">
                <div><strong>Telefone:</strong> (11) 9 9999-9999</div>
                <div><strong>Email:</strong> contato@amparoseniorcore.com.br</div>
                <div><strong>Endereço:</strong> Rua Exemplo, 123 — Bairro, Cidade</div>
              </div>

              <div className="mt-6">
                <a className="inline-flex items-center px-4 py-2 bg-teal-600 text-white rounded-md shadow" href="#contato">Enviar mensagem</a>
              </div>
            </div>

            <div>
              <div className="bg-white rounded-2xl shadow p-6 border border-slate-100">
                <ContactForm />
              </div>
            </div>
          </div>
        </section>

        {/* RODAPÉ */}
        <footer className="bg-slate-50 border-t border-slate-100 mt-12">
          <div className="max-w-6xl mx-auto px-6 py-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-3">
              <img src={LogoImg} alt="logo" className="w-10 h-10 object-contain"/>
              <div className="text-sm text-slate-600">© {new Date().getFullYear()} Amparo Sênior Core — Todos os direitos reservados</div>
            </div>

            <div className="text-sm text-slate-500">Política de privacidade • Termos de uso</div>
          </div>
        </footer>
      </main>
    </div>
  );
}

/* ----------------------------- Subcomponents ----------------------------- */

function Stat({ label, value }) {
  return (
    <div className="text-sm">
      <div className="text-xs text-slate-400">{label}</div>
      <div className="text-xl font-semibold">{value}</div>
    </div>
  );
}

function ServiceCard({ title, desc }) {
  return (
    <div className="bg-white rounded-2xl shadow p-6 border border-slate-100">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 flex items-center justify-center rounded-lg bg-teal-50 text-teal-600 font-bold">{title.charAt(0)}</div>
        <div>
          <div className="font-semibold">{title}</div>
          <div className="text-sm text-slate-500 mt-1">{desc}</div>
        </div>
      </div>
    </div>
  );
}

function Testimonial({ name, text }) {
  return (
    <div className="bg-white rounded-2xl shadow p-6 border border-slate-100">
      <div className="text-slate-600">“{text}”</div>
      <div className="mt-4 font-semibold">{name}</div>
    </div>
  );
}

function ContactForm() {
  const [form, setForm] = React.useState({ name: "", phone: "", location: "", message: "" });
  const [sent, setSent] = React.useState(false);

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  function handleSubmit(e) {
    e.preventDefault();
    // Placeholder: integrate with backend or email service here
    console.log("Enviar contato", form);
    setSent(true);
    setTimeout(() => setSent(false), 4000);
    setForm({ name: "", phone: "", location: "", message: "" });
  }

  return (
    <form onSubmit={handleSubmit} className="mt-4 space-y-3">
      <input name="name" value={form.name} onChange={handleChange} className="w-full border border-slate-200 rounded-md px-3 py-2" placeholder="Nome completo" required />
      <input name="phone" value={form.phone} onChange={handleChange} className="w-full border border-slate-200 rounded-md px-3 py-2" placeholder="Telefone / WhatsApp" required />
      <input name="location" value={form.location} onChange={handleChange} className="w-full border border-slate-200 rounded-md px-3 py-2" placeholder="Cidade / Bairro" />
      <textarea name="message" value={form.message} onChange={handleChange} className="w-full border border-slate-200 rounded-md px-3 py-2" rows={3} placeholder="Breve descrição das necessidades" />
      <div className="flex gap-2">
        <button type="submit" className="flex-1 px-4 py-2 bg-teal-600 text-white rounded-md">Enviar</button>
        <button type="button" className="flex-1 px-4 py-2 border border-slate-200 rounded-md" onClick={() => window.alert('Ligar para (11) 9 9999-9999')}>Ligar</button>
      </div>

      {sent && <div className="text-sm text-teal-600">Mensagem enviada! Entraremos em contato em até 24h úteis.</div>}
    </form>
  );
}
